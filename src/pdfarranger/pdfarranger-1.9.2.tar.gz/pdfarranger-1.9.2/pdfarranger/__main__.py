import sys
from pdfarranger import pdfarranger

pdfarranger.PdfArranger().run(sys.argv)
